Team Name

	5Bits

Team Members

	Stuart Barclay 	- 15015069
	Quinton Coetzee - 18028510
	Alistair Payn 	- 14272289
	Danré Retief 	- 14126461
	Thato Tshukudu 	- 18010408


Projects Tendered for

	Home Security System
	Watchdog
	AI Online Assistant Fake News Detector